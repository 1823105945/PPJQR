//
//  ISEResultSentence.m
//  IFlyMSCDemo
//
//  Created by 张剑 on 15/3/6.
//
//

#import "ISEResultSentence.h"

@implementation ISEResultSentence

@end
